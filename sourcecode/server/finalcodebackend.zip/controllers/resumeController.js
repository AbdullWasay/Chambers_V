const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');

AWS.config.update({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION
});

const s3 = new AWS.S3();

const uploadResume = async (req, res) => {
    try {
      const file = req.file;
      const params = {
        Bucket: process.env.AWS_S3_BUCKET,
        Key: `textract-output/${uuidv4()}-${file.originalname}`, // corrected path
        Body: file.buffer,
        ContentType: file.mimetype,
      };
      const data = await s3.upload(params).promise();
      res.json({ message: 'File uploaded successfully', data });
    } catch (error) {
      console.error('Upload error:', error);
      res.status(500).json({ error: 'Error uploading file' });
    }
  };


  const getRewrittenResume = async (req, res) => {
    try {
      const { key } = req.query; // frontend will send the key

      console.log('Fetching rewritten resume with key:', key);

      if (!key) {
        return res.status(400).json({ error: 'Missing key parameter' });
      }

      // First try to find the exact file with the key
      try {
        const params = {
          Bucket: process.env.AWS_S3_BUCKET,
          Key: `rewritten-resumes/${key}`, // Try the exact key first
        };

        console.log('Trying exact key S3 params:', params);
        const data = await s3.getObject(params).promise();
        console.log('S3 data received with exact key, content length:', data.Body.length);

        const jsonContent = JSON.parse(data.Body.toString('utf-8'));
        console.log('JSON parsed successfully');

        res.setHeader('Content-Type', 'application/json');
        return res.send(jsonContent);
      } catch (exactKeyError) {
        console.log('Exact key not found, trying to find file with key in the name...');

        // If exact key fails, try to find a file that contains the key in its name
        try {
          // List all files in the rewritten-resumes folder
          const listParams = {
            Bucket: process.env.AWS_S3_BUCKET,
            Prefix: 'rewritten-resumes/'
          };

          const listData = await s3.listObjectsV2(listParams).promise();
          console.log(`Found ${listData.Contents.length} objects in the bucket`);

          // Filter out the folder itself and only return actual files
          const files = listData.Contents.filter(item => !item.Key.endsWith('/'));
          console.log(`Found ${files.length} files after filtering`);

          // Try to find a file that contains the key in its name
          const matchingFile = files.find(file => file.Key.includes(key));

          if (matchingFile) {
            console.log('Found matching file:', matchingFile.Key);

            const getParams = {
              Bucket: process.env.AWS_S3_BUCKET,
              Key: matchingFile.Key
            };

            const fileData = await s3.getObject(getParams).promise();
            console.log('File content received, size:', fileData.Body.length);

            const jsonContent = JSON.parse(fileData.Body.toString('utf-8'));
            console.log('JSON parsed successfully');

            res.setHeader('Content-Type', 'application/json');
            return res.send(jsonContent);
          } else {
            // If no matching file is found, return the latest file
            console.log('No matching file found, returning the latest file...');

            // Sort by LastModified date (newest first)
            files.sort((a, b) => new Date(b.LastModified) - new Date(a.LastModified));

            if (files.length > 0) {
              // Get the most recent file
              const latestFile = files[0];
              console.log('Latest file:', latestFile.Key, 'Last modified:', latestFile.LastModified);

              const getParams = {
                Bucket: process.env.AWS_S3_BUCKET,
                Key: latestFile.Key
              };

              const fileData = await s3.getObject(getParams).promise();
              console.log('Latest file content received, size:', fileData.Body.length);

              const jsonContent = JSON.parse(fileData.Body.toString('utf-8'));
              console.log('JSON parsed successfully');

              res.setHeader('Content-Type', 'application/json');
              return res.send(jsonContent);
            } else {
              return res.status(404).json({
                error: 'No resumes found in the bucket',
                details: `No files found in rewritten-resumes/ in bucket ${process.env.AWS_S3_BUCKET}`
              });
            }
          }
        } catch (listError) {
          console.error('Error listing or processing files:', listError);
          throw listError;
        }
      }
    } catch (error) {
      console.error('Fetch rewritten resume error:', error);
      res.status(500).json({
        error: 'Error fetching resume',
        message: error.message
      });
    }
  };


module.exports = { uploadResume, getRewrittenResume };


