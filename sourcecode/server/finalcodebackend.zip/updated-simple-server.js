// A simple Express server to test AWS S3 connectivity
const express = require('express');
const cors = require('cors');
const AWS = require('aws-sdk');
const dotenv = require('dotenv');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const { v4: uuidv4 } = require('uuid');

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadDir = path.join(__dirname, 'uploads');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueId = uuidv4();
    const originalName = file.originalname;
    cb(null, `${uniqueId}-${originalName}`);
  }
});

const upload = multer({ storage: storage });

// Load environment variables
const dotenvPath = path.resolve(__dirname, '.env');
if (fs.existsSync(dotenvPath)) {
  console.log(`Loading environment variables from ${dotenvPath}`);
  dotenv.config({ path: dotenvPath });
} else {
  console.error(`ERROR: .env file not found at ${dotenvPath}`);
}

// Log environment variables
console.log('Environment Variables:');
console.log('AWS_REGION:', process.env.AWS_REGION);
console.log('AWS_S3_BUCKET:', process.env.AWS_S3_BUCKET);
console.log('AWS_ACCESS_KEY_ID:', process.env.AWS_ACCESS_KEY_ID ? '****' + process.env.AWS_ACCESS_KEY_ID.slice(-4) : 'Not set');
console.log('AWS_SECRET_ACCESS_KEY:', process.env.AWS_SECRET_ACCESS_KEY ? '****' : 'Not set');

// Configure AWS SDK
AWS.config.update({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION || 'us-east-1'
});

// Create S3 service object
const s3 = new AWS.S3({
  apiVersion: '2006-03-01',
  s3ForcePathStyle: true,
  signatureVersion: 'v4'
});

// Create Express app
const app = express();

// Configure CORS
app.use(cors({
  origin: ['http://localhost:3000', 'http://localhost:3001', 'http://localhost:3002', 'http://localhost:3003'],
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Add CORS headers to all responses
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  next();
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Simple test route
app.get('/test', (req, res) => {
  res.json({ message: 'Server is working!' });
});

// Handle file uploads
app.post('/upload', upload.single('file'), async (req, res) => {
  try {
    console.log('File upload request received');
    console.log('Request headers:', req.headers);
    console.log('Request body:', req.body);

    if (!req.file) {
      console.log('No file in request');
      return res.status(400).json({ error: 'No file uploaded' });
    }

    console.log('File uploaded:', req.file.filename);
    console.log('File details:', {
      originalname: req.file.originalname,
      mimetype: req.file.mimetype,
      size: req.file.size,
      path: req.file.path
    });

    // Generate a unique key for the file in S3
    const fileKey = `rewritten-resumes/${req.file.filename.replace(/\.[^/.]+$/, '')}.json`;

    // Generate resume data based on the uploaded file
    const resumeData = generateResumeData(req.file.originalname);

    // Convert the resume data to JSON string
    const resumeJson = JSON.stringify(resumeData, null, 2);

    // Upload the JSON to S3
    const params = {
      Bucket: process.env.AWS_S3_BUCKET,
      Key: fileKey,
      Body: resumeJson,
      ContentType: 'application/json'
    };

    console.log('Uploading to S3 with params:', JSON.stringify(params));

    try {
      const s3UploadResult = await s3.putObject(params).promise();
      console.log('S3 upload successful:', s3UploadResult);

      return res.json({
        message: 'File uploaded and processed successfully',
        data: {
          Key: fileKey,
          Location: `https://${process.env.AWS_S3_BUCKET}.s3.amazonaws.com/${fileKey}`,
          originalName: req.file.originalname,
          size: req.file.size,
          resumeKey: fileKey // Add the specific key for the client to use
        }
      });
    } catch (s3Error) {
      console.error('Error uploading to S3:', s3Error);
      return res.status(500).json({
        error: 'Error uploading to S3',
        message: s3Error.message
      });
    }
  } catch (error) {
    console.error('Error handling file upload:', error);
    return res.status(500).json({
      error: 'Error handling file upload',
      message: error.message
    });
  }
});

// Get a specific resume by key
app.get('/rewritten-resume', async (req, res) => {
  try {
    console.log('Fetching specific rewritten resume...');
    const resumeKey = req.query.key;

    if (!resumeKey) {
      return res.status(400).json({
        error: 'Missing key parameter',
        message: 'Please provide a key parameter to fetch a specific resume'
      });
    }

    console.log('Fetching resume with key:', resumeKey);

    const getParams = {
      Bucket: process.env.AWS_S3_BUCKET,
      Key: resumeKey
    };

    try {
      const fileData = await s3.getObject(getParams).promise();
      console.log('File content received, size:', fileData.Body.length);

      try {
        const jsonContent = JSON.parse(fileData.Body.toString('utf-8'));
        console.log('JSON parsed successfully');

        res.setHeader('Content-Type', 'application/json');
        return res.send(jsonContent);
      } catch (parseError) {
        console.error('Error parsing JSON:', parseError);

        const rawContent = fileData.Body.toString('utf-8');
        console.log('Raw content (first 200 chars):', rawContent.substring(0, 200));

        return res.status(500).json({
          error: 'Error parsing resume data',
          message: parseError.message,
          rawData: rawContent.substring(0, 200) + '...'
        });
      }
    } catch (getError) {
      console.error('Error getting object:', getError);
      return res.status(404).json({
        error: 'Resume not found',
        message: `Could not find resume with key: ${resumeKey}`,
        params: getParams
      });
    }
  } catch (error) {
    console.error('Error fetching specific rewritten resume:', error);
    return res.status(500).json({
      error: 'Error fetching specific rewritten resume',
      message: error.message
    });
  }
});

// Get latest rewritten resume
app.get('/latest-rewritten-resume', async (req, res) => {
  try {
    console.log('Fetching latest rewritten resume...');

    // Try multiple prefixes to find the resume
    const prefixesToTry = [
      'rewritten-resumes/',
      'rewritten_resumes/',
      'rewrittenresumes/',
      'rewritten-resume/',
      'rewritten/'
    ];

    let allFiles = [];

    // Try each prefix
    for (const prefix of prefixesToTry) {
      console.log(`Trying prefix: ${prefix}`);

      const params = {
        Bucket: process.env.AWS_S3_BUCKET,
        Prefix: prefix
      };

      try {
        const data = await s3.listObjectsV2(params).promise();
        console.log(`Found ${data.Contents ? data.Contents.length : 0} objects with prefix '${prefix}'`);

        if (data.Contents && data.Contents.length > 0) {
          // Filter out folders
          const files = data.Contents.filter(item => !item.Key.endsWith('/'));
          console.log(`Found ${files.length} files after filtering for prefix '${prefix}'`);

          // Add these files to our collection
          allFiles = [...allFiles, ...files];
        }
      } catch (listError) {
        console.error(`Error listing objects with prefix '${prefix}':`, listError);
      }
    }

    console.log(`Found a total of ${allFiles.length} files across all prefixes`);

    if (allFiles.length === 0) {
      // List all objects in the bucket to see what's available
      try {
        console.log('Listing all objects in the bucket to debug...');
        const allObjectsParams = {
          Bucket: process.env.AWS_S3_BUCKET
        };

        const allObjectsData = await s3.listObjectsV2(allObjectsParams).promise();
        console.log(`Found ${allObjectsData.Contents ? allObjectsData.Contents.length : 0} total objects in the bucket`);

        if (allObjectsData.Contents && allObjectsData.Contents.length > 0) {
          console.log('Sample of objects in the bucket:');
          allObjectsData.Contents.slice(0, 10).forEach((item, index) => {
            console.log(`${index + 1}. ${item.Key} (${item.LastModified})`);
          });

          // Return the list of all objects for debugging
          return res.status(404).json({
            error: 'No rewritten resumes found in the expected prefixes',
            message: 'Could not find any resume files in the expected locations',
            prefixesTried: prefixesToTry,
            allObjects: allObjectsData.Contents.slice(0, 20).map(item => ({
              key: item.Key,
              lastModified: item.LastModified
            }))
          });
        }
      } catch (listAllError) {
        console.error('Error listing all objects:', listAllError);
      }

      return res.status(404).json({
        error: 'No rewritten resumes found in the bucket',
        message: 'The server could not find any resume files in the S3 bucket',
        prefixesTried: prefixesToTry
      });
    }

    // Sort by LastModified date (newest first)
    allFiles.sort((a, b) => new Date(b.LastModified) - new Date(a.LastModified));

    // Get the most recent file
    const latestFile = allFiles[0];
    console.log('Latest file:', latestFile.Key);
    console.log('Last modified:', latestFile.LastModified);

    // Now fetch the content of this file
    const getParams = {
      Bucket: process.env.AWS_S3_BUCKET,
      Key: latestFile.Key
    };

    console.log('Fetching file content with params:', JSON.stringify(getParams));

    try {
      // Try to get the object
      const fileData = await s3.getObject(getParams).promise();
      console.log('File content received, size:', fileData.Body.length);

      try {
        // Try to parse the JSON
        const jsonContent = JSON.parse(fileData.Body.toString('utf-8'));
        console.log('JSON parsed successfully');

        res.setHeader('Content-Type', 'application/json');
        return res.send(jsonContent);
      } catch (parseError) {
        console.error('Error parsing JSON:', parseError);

        // Log the raw content for debugging
        const rawContent = fileData.Body.toString('utf-8');
        console.log('Raw content (first 200 chars):', rawContent.substring(0, 200));

        return res.status(500).json({
          error: 'Error parsing resume data',
          message: parseError.message,
          rawData: rawContent.substring(0, 200) + '...' // Send first 200 chars for debugging
        });
      }
    } catch (getError) {
      console.error('Error getting object:', getError);
      return res.status(500).json({
        error: 'Error getting object from S3',
        message: getError.message,
        params: getParams
      });
    }
  } catch (error) {
    console.error('Error fetching latest rewritten resume:', error);
    return res.status(500).json({
      error: 'Error fetching latest rewritten resume',
      message: error.message
    });
  }
});

// Test S3 connection
app.get('/test-s3', async (req, res) => {
  try {
    console.log('Testing S3 connection...');

    const params = {
      Bucket: process.env.AWS_S3_BUCKET
    };

    const data = await s3.listObjectsV2(params).promise();
    console.log(`Found ${data.Contents ? data.Contents.length : 0} objects in the bucket`);

    res.json({
      message: 'S3 connection successful',
      objectCount: data.Contents ? data.Contents.length : 0,
      sampleObjects: data.Contents ? data.Contents.slice(0, 5).map(item => ({
        key: item.Key,
        lastModified: item.LastModified
      })) : []
    });
  } catch (error) {
    console.error('Error testing S3 connection:', error);
    res.status(500).json({
      error: 'Error testing S3 connection',
      message: error.message,
      stack: error.stack
    });
  }
});

// Generate a unique resume based on the filename
const generateResumeData = (filename) => {
  // Extract a name from the filename if possible
  let name = "John Doe"; // Default name

  // Try to extract a name from the filename
  const nameMatch = filename.match(/([A-Z][a-z]+)[-_]([A-Z][a-z]+)/);
  if (nameMatch && nameMatch.length >= 3) {
    name = `${nameMatch[1]} ${nameMatch[2]}`;
  } else if (filename.includes("Resume") || filename.includes("CV")) {
    // Use part of the filename as the name
    const parts = filename.split(/[-_\.]/);
    if (parts.length >= 2) {
      name = `${parts[0]} ${parts[1]}`;
    }
  }

  // Generate a random phone number
  const generatePhone = () => {
    const areaCode = Math.floor(Math.random() * 900) + 100;
    const firstPart = Math.floor(Math.random() * 900) + 100;
    const secondPart = Math.floor(Math.random() * 9000) + 1000;
    return `${areaCode}-${firstPart}-${secondPart}`;
  };

  // Generate a random email based on the name
  const generateEmail = (name) => {
    const domains = ["gmail.com", "yahoo.com", "outlook.com", "hotmail.com", "example.com"];
    const nameParts = name.toLowerCase().split(" ");
    const randomNum = Math.floor(Math.random() * 1000);
    const domain = domains[Math.floor(Math.random() * domains.length)];
    return `${nameParts.join(".")}${randomNum}@${domain}`;
  };

  // Generate random skills based on the file type
  const generateSkills = (filename) => {
    // Define skill categories and their possible skills
    const skillCategories = {
      "Programming Languages": [
        "JavaScript", "Python", "Java", "C++", "TypeScript", "Ruby", "Swift",
        "Kotlin", "Go", "Rust", "C#", "PHP", "Scala", "Perl", "Haskell"
      ],
      "Web Development": [
        "HTML", "CSS", "React", "Angular", "Vue.js", "Node.js", "Express",
        "Django", "Flask", "Spring", "ASP.NET", "Laravel", "Ruby on Rails",
        "SASS", "Bootstrap", "Tailwind CSS", "jQuery"
      ],
      "Databases": [
        "SQL", "MySQL", "PostgreSQL", "MongoDB", "SQLite", "Oracle",
        "Microsoft SQL Server", "Redis", "Cassandra", "DynamoDB", "Firebase"
      ],
      "DevOps & Cloud": [
        "AWS", "Azure", "Google Cloud", "Docker", "Kubernetes", "Jenkins",
        "CircleCI", "Travis CI", "Terraform", "Ansible", "Puppet", "Chef"
      ],
      "Tools & Methodologies": [
        "Git", "GitHub", "GitLab", "Bitbucket", "Jira", "Agile", "Scrum",
        "Kanban", "TDD", "BDD", "CI/CD", "Microservices", "REST API", "GraphQL"
      ]
    };

    // Select 2-4 random categories
    const categories = Object.keys(skillCategories);
    const numCategories = Math.floor(Math.random() * 3) + 2; // 2-4 categories
    const selectedCategories = [];

    for (let i = 0; i < numCategories; i++) {
      const randomIndex = Math.floor(Math.random() * categories.length);
      const category = categories[randomIndex];

      // Avoid duplicates
      if (!selectedCategories.includes(category)) {
        selectedCategories.push(category);
      }
    }

    // For each selected category, pick 3-6 skills
    const result = selectedCategories.map(category => {
      const skills = skillCategories[category];
      const numSkills = Math.floor(Math.random() * 4) + 3; // 3-6 skills
      const selectedSkills = [];

      for (let i = 0; i < numSkills; i++) {
        const randomIndex = Math.floor(Math.random() * skills.length);
        const skill = skills[randomIndex];

        // Avoid duplicates
        if (!selectedSkills.includes(skill)) {
          selectedSkills.push(skill);
        }
      }

      return {
        category: category,
        items: selectedSkills
      };
    });

    return result;
  };

  // Generate random companies
  const companies = [
    "Google", "Microsoft", "Amazon", "Apple", "Facebook", "Netflix", "Tesla",
    "IBM", "Oracle", "Intel", "Adobe", "Salesforce", "Twitter", "Uber", "Airbnb",
    "LinkedIn", "Spotify", "Slack", "Zoom", "PayPal", "eBay", "Shopify"
  ];

  // Generate random job titles
  const jobTitles = [
    "Software Engineer", "Frontend Developer", "Backend Developer", "Full Stack Developer",
    "DevOps Engineer", "Data Scientist", "Machine Learning Engineer", "Product Manager",
    "UX Designer", "UI Developer", "QA Engineer", "Systems Architect", "Cloud Engineer",
    "Mobile Developer", "Game Developer", "Blockchain Developer", "Security Engineer"
  ];

  // Generate random universities
  const universities = [
    "Stanford University", "MIT", "Harvard University", "UC Berkeley", "Carnegie Mellon",
    "University of Washington", "Georgia Tech", "University of Michigan", "Cornell University",
    "University of Illinois", "Purdue University", "University of Texas", "UCLA", "NYU"
  ];

  // Generate random degree areas
  const degreeAreas = [
    "Computer Science", "Software Engineering", "Information Technology", "Data Science",
    "Artificial Intelligence", "Cybersecurity", "Computer Engineering", "Information Systems",
    "Electrical Engineering", "Mathematics", "Physics", "Business Informatics"
  ];

  // Generate a random year between 2010 and 2023
  const randomYear = () => 2010 + Math.floor(Math.random() * 14);

  // Generate a random month
  const randomMonth = () => {
    const months = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"];
    return months[Math.floor(Math.random() * months.length)];
  };

  // Generate a random date in YYYY-MM format
  const randomDate = () => `${randomYear()}-${randomMonth()}`;

  // Generate 1-3 random experiences
  const generateExperiences = () => {
    const numExperiences = Math.floor(Math.random() * 3) + 1;
    const experiences = [];

    for (let i = 0; i < numExperiences; i++) {
      const company = companies[Math.floor(Math.random() * companies.length)];
      const title = jobTitles[Math.floor(Math.random() * jobTitles.length)];
      const startDate = randomDate();
      const endDate = i === 0 ? "Present" : randomDate();

      // Generate ATS-optimized professional and detailed highlights
      const generateHighlights = (title, company) => {
        const highlights = [];

        // Add 3-5 professional highlights with measurable achievements and keywords
        const possibleHighlights = [
          `Spearheaded development of ${company}'s core ${title.toLowerCase()} initiatives, resulting in 30% improvement in system performance and $2.5M in annual cost savings.`,

          `Collaborated with cross-functional teams to deliver high-quality software solutions, achieving 100% on-time delivery across 15+ projects while maintaining budget constraints.`,

          `Implemented industry best practices for code quality and documentation, reducing bug reports by 25% and improving team productivity by 20%.`,

          `Mentored 8 junior developers and conducted 200+ code reviews, ensuring adherence to coding standards and reducing technical debt by 35%.`,

          `Optimized SQL database queries and application architecture, improving response times by 40% and handling 3x increase in user traffic without performance degradation.`,

          `Designed and implemented RESTful APIs and GraphQL endpoints that improved integration with 12+ third-party services, reducing integration time by 60%.`,

          `Developed automated testing frameworks with Jest and Cypress that increased code coverage from 65% to 95%, reducing production issues by 40%.`,

          `Led agile development processes including daily stand-ups and sprint planning, increasing team velocity by 25% and improving stakeholder satisfaction scores by 30%.`,

          `Refactored 50,000+ lines of legacy code to modern standards, reducing technical debt by 45% and improving application maintainability scores from 2.3 to 4.7/5.`,

          `Implemented CI/CD pipelines with Jenkins and GitHub Actions that streamlined the deployment process, reducing release time by 50% and enabling 3x more frequent deployments.`,

          `Utilized cloud technologies (AWS/Azure/GCP) to architect scalable solutions that handled peak loads of 1M+ concurrent users with 99.99% uptime.`,

          `Optimized front-end performance using React and Redux, reducing page load times by 65% and improving user engagement metrics by 40%.`,

          `Implemented microservices architecture using Docker and Kubernetes, improving system scalability and reducing infrastructure costs by 35%.`,

          `Developed data analytics dashboards that provided real-time insights, enabling data-driven decisions that increased conversion rates by 28%.`
        ];

        // Shuffle and select 3-5 highlights
        const shuffled = [...possibleHighlights].sort(() => 0.5 - Math.random());
        const numHighlights = Math.floor(Math.random() * 3) + 3; // 3-5 highlights

        for (let i = 0; i < numHighlights; i++) {
          highlights.push(shuffled[i]);
        }

        return highlights;
      };

      experiences.push({
        title,
        company,
        location: "Remote",
        startDate,
        endDate,
        highlights: generateHighlights(title, company)
      });
    }

    return experiences;
  };

  // Generate 1-2 random education entries
  const generateEducation = () => {
    const numEducation = Math.floor(Math.random() * 2) + 1;
    const education = [];

    for (let i = 0; i < numEducation; i++) {
      const institution = universities[Math.floor(Math.random() * universities.length)];
      const area = degreeAreas[Math.floor(Math.random() * degreeAreas.length)];
      const startDate = randomDate();
      const endDate = i === 0 ? "Present" : randomDate();

      education.push({
        institution,
        area,
        studyType: "Bachelor",
        startDate,
        endDate,
        gpa: (Math.random() * 1.5 + 2.5).toFixed(1) // Random GPA between 2.5 and 4.0
      });
    }

    return education;
  };

  // Generate an ATS-optimized professional summary
  const generateSummary = (name, title) => {
    // Use more targeted, keyword-rich summaries that will score higher in ATS systems
    const summaries = [
      `Results-driven ${title} with ${Math.floor(Math.random() * 8) + 3} years of experience developing scalable and efficient solutions. Proven expertise in full-stack development, agile methodologies, and cloud infrastructure. Passionate about leveraging cutting-edge technology to solve complex business challenges and drive measurable innovation.`,

      `Dedicated ${title} with a proven track record of designing and implementing high-performance applications that exceed KPIs. Skilled in CI/CD pipelines, test-driven development, and microservices architecture. Adept at collaborating with cross-functional teams to deliver exceptional software solutions that drive business growth.`,

      `Innovative ${title} specializing in building robust, scalable applications with 99.9% uptime. Expert in cloud-native technologies, containerization, and serverless architecture. Combines strong technical expertise with excellent problem-solving abilities to create efficient solutions that optimize performance and enhance user experience.`,

      `Detail-oriented ${title} with extensive experience in full software development lifecycle using agile methodologies. Skilled in translating complex business requirements into technical solutions while maintaining code quality and performance standards. Consistently delivers projects on time and under budget with measurable business impact.`,

      `Forward-thinking ${title} with expertise in modern development practices and emerging technologies. Proficient in multiple programming languages, frameworks, and cloud platforms. Committed to continuous learning and applying industry best practices to deliver high-quality, maintainable code that meets business objectives and drives digital transformation.`
    ];

    return summaries[Math.floor(Math.random() * summaries.length)];
  };

  // Select a job title
  const title = jobTitles[Math.floor(Math.random() * jobTitles.length)];

  // Create the resume data
  return {
    basics: {
      name: name,
      title: title,
      email: generateEmail(name),
      phone: generatePhone(),
      location: "San Francisco, CA",
      summary: generateSummary(name, title)
    },
    experience: generateExperiences(),
    education: generateEducation(),
    skills: generateSkills(filename)
  };
};

// Start the server
const PORT = 3002; // Use port 3002
app.listen(PORT, () => {
  console.log(`Simple server running on port ${PORT}`);
  console.log(`Test the server at: http://localhost:${PORT}/test`);
  console.log(`Test S3 connection at: http://localhost:${PORT}/test-s3`);
  console.log(`Get latest resume at: http://localhost:${PORT}/latest-rewritten-resume`);
});
